 const data =
[
    {
    id: 1,
    firstname:'Niraj ', 
    lastname:' Patil',
    students:[
        {
            id:0,
            firstname:'Anna',
            lastname:' Patil',
            amount:120
        },
        {
            id:1,
            firstname:'Appa',
            lastname:' Patil',
            amount:40
        },
        {
            id:2,
            firstname:'Chandu',
            lastname:' Patil',
            amount:40
        }       
    ] ,  
    invoiceno: '123',
    totalvalue:'200',
    createddate: "2019-01-01T17:57:28.556094Z",
    duedate: "2019-01-01T17:57:28.556094Z",
    status:"Paid"
    },
    {
        id: 2,
        firstname:'Sachin ', 
        lastname:' Surve',
        students:[
            {
                id:0,
                firstname:'Dimple ',
                lastname:' Surve',
                amount:110}
            
        ]  ,   
        invoiceno: '124',
        totalvalue:'110',
        createddate: "2019-01-02T17:57:28.556094Z",
        duedate: "2019-01-02T17:57:28.556094Z",
        status:"Paid"
    },
    {
        id: 3,
        firstname:'Pravin ', 
        lastname:' Thorve',  
        students:[
            {
                id:0,
                firstname:'Preeti ',
                lastname:' Thorve',
                amount:100},
            {
                id:1,
                firstname:'Santosh',
                lastname:' Thorve',
                amount:20
            }

        ]  ,  
        invoiceno: '125',
        totalvalue:'120',
        createddate: "2019-01-10T17:57:28.556094Z",
        duedate: "2019-01-10T17:57:28.556094Z",
        status:"Pending"
    },
    {
        id: 4,
        firstname:'Dipak ', 
        lastname:' Gadekar',
        students:[
            {
                id:0,
                firstname:'Nitin',
                lastname:' Joshi',
                amount:75},
            {
                id:1,
                firstname:'Pravin ',
                lastname:' Joshi',
                amount:75
            }

        ]  ,   
        invoiceno: '126',
        totalvalue:'150',
        createddate: "2019-01-11T17:57:28.556094Z",
        duedate: "2019-01-10T17:57:28.556094Z",
        status:"Pending"
    },
    {
        id: 5,
        firstname:'Gaurav ', 
        lastname:' Bodas',
        students:[
            {
                id:0,
                firstname:'Neel',
                lastname:' Bodas',
                amount:100}
        ]  ,  
        invoiceno: '127',
        totalvalue:'100',
        createddate: "2019-01-12T17:57:28.556094Z",
        duedate: "2019-01-10T17:57:28.556094Z",
        status:"Pending"
    },
    {
        id: 6,
        firstname:'Madan ', 
        lastname:' Oak',  
        students:[
            {
                id:0,
                firstname:'Ved',
                lastname:' Oak',
                amount:80},
            {
                id:1,
                firstname:'Vardha',
                lastname:' Oak',
                amount:40
            }

        ]  ,
        invoiceno: '128',
        totalvalue:'120',
        createddate: "2019-01-02T17:57:28.556094Z",
        duedate: "2019-01-10T17:57:28.556094Z",
        status:"Paid"
    },
    {
        id: 7,
        firstname:'Amol ', 
        lastname:' Nalavade',  
        students:[
            {
                id:0,
                firstname:'Nana',
                lastname:' Chaudhari',
                amount:100
            },
            {
                id:1,
                firstname:'Rajesh',
                lastname:' Chaudhari',
                amount:60
            }
        ] ,
        invoiceno: '129',
        totalvalue:'160',
        createddate: "2019-01-02T17:57:28.556094Z",
        duedate: "2019-01-10T17:57:28.556094Z",
        status:"Paid"
    }
];

export default data;